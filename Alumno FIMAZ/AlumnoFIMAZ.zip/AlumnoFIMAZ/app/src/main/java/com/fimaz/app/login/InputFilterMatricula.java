package com.fimaz.app.login;
import android.text.InputFilter;
import android.text.Spanned;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputFilterMatricula implements InputFilter {

    private static final int MAX_LENGTH = 9;

    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        // Verificar si el texto de destino excede la longitud máxima
        int destLength = dest.length();
        int sourceLength = end - start;
        int totalLength = destLength + sourceLength;

        if (totalLength > MAX_LENGTH) {
            // Calcular cuántos caracteres exceden la longitud máxima
            int exceededLength = totalLength - MAX_LENGTH;

            // Ajustar la longitud de la fuente para permitir solo los caracteres que caben
            int adjustedSourceEnd = end - exceededLength;

            // Devolver solo los caracteres que caben dentro de la longitud máxima
            return source.subSequence(start, adjustedSourceEnd);
        }

        // Verificar si el texto de origen contiene caracteres válidos (números y guiones)
        Pattern pattern = Pattern.compile("^[0-9-]*$");
        Matcher matcher = pattern.matcher(source);

        // Si no coincide con la expresión regular, no permitir el cambio
        if (!matcher.matches()) {
            return "";
        }

        // Permitir el cambio ya que no excede la longitud máxima ni contiene caracteres inválidos
        return null;
    }
}
