package com.fimaz.app.fragments;

import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import com.fimaz.app.R;
import com.fimaz.app.moodle.vistaFIMAZ;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class RecursosFragment extends Fragment {

    private WebView webView;
    private WebView webViewMoodle;
    private Vibrator vibrator;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);// Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_recursos, container, false);


        //Boton para abrir moodle
        Button btnMoodle = rootView.findViewById(R.id.btnMoodle);
        btnMoodle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performHapticFeedBack(v);
                abrirMoodle(new vistaFIMAZ());
            }
        });

        //Abrir bottom sheet dialog
        Button btnCalendario = rootView.findViewById(R.id.btnCalendario);
        btnCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performHapticFeedBack(v);

                BottomSheetDialog bottomSheetDialog= new BottomSheetDialog(requireContext());
                View view1 = LayoutInflater.from(requireContext()).inflate(R.layout.bottom_sheet_layout_recursos, null);
                bottomSheetDialog.setContentView(view1);

                bottomSheetDialog.setCancelable(true);
                bottomSheetDialog.show();

                int maxHeight = getResources().getDisplayMetrics().heightPixels;
                bottomSheetDialog.getBehavior().setPeekHeight(maxHeight);


                webView = view1.findViewById(R.id.calendarioWebView);

                webView.clearCache(true);

                webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

                //Configurar opcioes para el webView
                webView.setWebViewClient(new WebViewClient(){
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
                        Toast.makeText(getActivity(),"Error al cargar el calendario", Toast.LENGTH_SHORT).show();
                    }
                });


                WebSettings webSettings = webView.getSettings();

                // Habilitar JavaScript y la carga de contenido remoto
                webSettings.setJavaScriptEnabled(true);
                webSettings.setAllowContentAccess(true);

                // Habilitar la capacidad de zoom
                webSettings.setBuiltInZoomControls(true);
                webSettings.setDisplayZoomControls(false);

                // Ajustar la imagen al ancho del WebView
                webSettings.setLoadWithOverviewMode(true);
                webSettings.setUseWideViewPort(true);


                webView.loadUrl("https://www.uas.edu.mx/img/servicios/calendarios/Calendario-2023-2024.jpg");


                Button dismmisBtn = view1.findViewById(R.id.dismiss);

                dismmisBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       bottomSheetDialog.dismiss();
                    }
                });

            }
        });

        return rootView;
    }

    private void abrirMoodle(Fragment fragment){
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    // Método para realizar la vibración háptica
    private void performHapticFeedBack(View v){
        getView().performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);

        // También puedes usar Vibrator para dispositivos más antiguos
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator != null) {
            // Ajusta los parámetros de la vibración según tu preferencia
            VibrationEffect effect = VibrationEffect.createOneShot(1, VibrationEffect.DEFAULT_AMPLITUDE);
            vibrator.vibrate(effect);
        } else {
            // Para versiones anteriores a Oreo
            if (vibrator != null) {
                vibrator.vibrate(2);
            }
        }
    }
}