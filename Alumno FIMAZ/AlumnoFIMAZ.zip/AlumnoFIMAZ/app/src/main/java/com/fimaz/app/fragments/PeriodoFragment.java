package com.fimaz.app.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.fimaz.app.AlumnoViewModel;
import com.fimaz.app.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.lang.reflect.Type;

public class PeriodoFragment extends Fragment {

    private static final String ARG_PERIODO = "periodo";
    private TableLayout tableLayout;
    private TextView loadingTextView, noKardexTextView;
    private RequestQueue requestQueue;
    private String matricula;
    private AlumnoViewModel alumnoViewModel;
    private static final String PREFS_NAME = "MyPrefsFile";

    public static PeriodoFragment newInstance(int periodo) {
        PeriodoFragment fragment = new PeriodoFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PERIODO, periodo);
        fragment.setArguments(args);
        return fragment;
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Obtener el view model
        alumnoViewModel = new ViewModelProvider(requireActivity()).get(AlumnoViewModel.class);

        // Observador de los datos del alumno
        alumnoViewModel.getDatosAlumnoJSON().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String datosAlumnoJSON) {
                if (datosAlumnoJSON != null && !datosAlumnoJSON.isEmpty()) {
                    Log.d("JSON-PERIODO-FRAG", "Datos alumno: " + datosAlumnoJSON);
                    
                } else {
                    Log.d("ERROR-PERIODO-FRAG", "No se recibieron los datos del alumno");

                    // Llamar a consultaCalificaciones con matrícula guardada en SharedPreferences
                    String savedMatricula = getMatriculaFromSharedPreferences();
                    if (getArguments() != null && savedMatricula != null) {
                        int periodo = getArguments().getInt(ARG_PERIODO);
                        consultaCalificaciones(periodo, savedMatricula);
                    }
                }
            }

            private String getMatriculaFromSharedPreferences() {
                SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                // Si no se encuentra la matrícula, devuelve null
                return sharedPreferences.getString("matricula", null);
            }
        });
    }

    private void saveMatriculaToSharedPreferences(String matricula){
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_periodo, container, false);

        tableLayout = rootView.findViewById(R.id.tableLayout);
        loadingTextView = rootView.findViewById(R.id.loadingTextView);
        noKardexTextView = rootView.findViewById(R.id.noKardexTextView);
        requestQueue = Volley.newRequestQueue(requireContext());

        // Si la matrícula no está vacía, consultar calificaciones
        if (matricula != null) {
            if (getArguments() != null) {
                int periodo = getArguments().getInt(ARG_PERIODO);
                consultaCalificaciones(periodo, matricula);
            }
        }

        return rootView;
    }

    private void consultaCalificaciones(int periodoSeleccionado, String matricula) {
        String URL = "https:///connectmzt.com/app/indexCalificaciones.php";

        // Mostrar el texto de "Cargando..."
        loadingTextView.setVisibility(View.VISIBLE);

        JSONObject postData = new JSONObject();
        try {
            postData.put("periodo", periodoSeleccionado);
            postData.put("matricula", matricula);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        Log.d("JSON-POST", "DATA:" + postData);

        CustomJsonArrayRequest request = new CustomJsonArrayRequest(Request.Method.POST, URL, postData,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Verificar si el fragmento está adjunto antes de acceder al contexto
                        if (!isAdded()) {
                            return;
                        }

                        requireActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                try {
                                    // Limpiar la tabla antes de agregar nuevas filas
                                    tableLayout.removeAllViews();

                                    // Ocultar el texto de "Cargando..."
                                    loadingTextView.setVisibility(View.GONE);



                                    // Agregar la fila de encabezados
                                    TableRow headerRow = new TableRow(requireContext());

                                    // Cargar la fuente personalizada desde los recursos
                                    Typeface customFont = ResourcesCompat.getFont(requireContext(), R.font.montserrat_bold);

                                    // Crear los TextView para los encabezados de las filas de la tabla
                                    TextView materiaHeader = createTextView("Materia", true, customFont, 1f);
                                    TextView grupoHeader = createTextView("Grupo", true, customFont, 1f);
                                    TextView periodoHeader = createTextView("Periodo", true, customFont, 1f);
                                    TextView calificacionHeader = createTextView("Calificación", true, customFont, 1f);


                                    // Obtener el modo actual del tema
                                    int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
                                    boolean isNightMode = nightModeFlags == Configuration.UI_MODE_NIGHT_YES;

                                    // Obtener el color de fondo según el modo
                                    int colorPrimary = isNightMode ?
                                            ContextCompat.getColor(requireContext(), R.color.dark_teal) :
                                            ContextCompat.getColor(requireContext(), R.color.turquoise);


                                    // Crear un objeto ColorDrawable con el color obtenido
                                    ColorDrawable colorDrawable = new ColorDrawable(colorPrimary);


                                    headerRow.setBackground(colorDrawable);

                                    // Agregar los TextView a la fila de encabezados
                                    headerRow.addView(materiaHeader);
                                    headerRow.addView(grupoHeader);
                                    headerRow.addView(periodoHeader);
                                    headerRow.addView(calificacionHeader);

                                    tableLayout.addView(headerRow);

                                    // Iterar sobre el JSONArray y agregar filas a la tabla
                                    for (int i = 0; i < response.length(); i++) {
                                        JSONObject calificacion = response.getJSONObject(i);



                                        // Crear una nueva fila
                                        TableRow row = new TableRow(requireContext());

                                        Typeface customFont2 = ResourcesCompat.getFont(requireContext(), R.font.montserrat_medium);

                                   
                                        // Extraer y manejar los datos de la calificación
                                        String materia = calificacion.isNull("Materia") ? calificacion.getString("Optativa") : calificacion.getString("Materia");   // Obtener el nombre de la materia
                                        int grupo = calificacion.getInt("Grupo");
                                        int periodo = calificacion.getInt("periodo");
                                        String calificacionAlumno = calificacion.getString("CalificacionAlumno");

                                        TextView materiaRow = createTextView(materia, false, customFont2,1f);
                                        TextView grupoRow = createTextView(String.valueOf(grupo), false, customFont2, 1f);
                                        TextView periodoRow = createTextView(String.valueOf(periodo), false, customFont2, 1f);
                                        TextView calificacionAlumnoRow = createTextView(calificacionAlumno, false, customFont2, 1f);


                                        // Agregar celdas a la fila
                                        row.addView(materiaRow);
                                        row.addView(grupoRow);
                                        row.addView(periodoRow);
                                        row.addView(calificacionAlumnoRow);

                                        // Agregar la fila a la tabla
                                        tableLayout.addView(row);
                                    }
                                } 
                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (!isAdded()) {
                            return;
                        }
                        // Manejar errores de la solicitud
                        requireActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // Ocultar el texto de "Cargando..." en caso de error
                                loadingTextView.setVisibility(View.GONE);

                                error.printStackTrace();

                                noKardexTextView.setVisibility(View.VISIBLE);
                                //Toast.makeText(getContext(), "Error en la solicitud", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

        requestQueue.add(request);
    }

    private TextView createTextView(String text, boolean isHeader, Typeface typeface, float weight) {
        TextView textView = new TextView(requireContext());

        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        textView.setGravity(View.TEXT_ALIGNMENT_CENTER);
        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        TableRow.LayoutParams params = new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        textView.setLayoutParams(params);
        textView.setTypeface(typeface);

        return textView;
    }

    private static class CustomJsonArrayRequest extends JsonArrayRequest {
        private final JSONObject jsonRequest;

        public CustomJsonArrayRequest(int method, String url, JSONObject jsonRequest,
                                      Response.Listener<JSONArray>, Response.ErrorListener errorListener) {
            super(method, url, null, listener);
            
        }

        @Override
        public byte[] getBody() {
            return JsonRequest == null ? null : jsonRequest.toString().getBytes();
        }

        @Override
        public String getBodyContentType() {
            return "application/json; charset=utf-8";
        }
    }
}
