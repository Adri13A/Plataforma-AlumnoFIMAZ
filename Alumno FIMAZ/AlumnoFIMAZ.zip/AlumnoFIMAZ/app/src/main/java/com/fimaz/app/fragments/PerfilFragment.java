package com.fimaz.app.fragments;

import static com.fimaz.app.login.MainActivity.PREFS_NAME;

import static java.util.ResourceBundle.clearCache;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.fimaz.app.AlumnoViewModel;
import com.fimaz.app.R;
import com.fimaz.app.bottomsheet.PerfilBottomSheet;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

public class PerfilFragment extends Fragment {

    private LogoutListener logoutListener;
    private Vibrator vibrator;
    private AlumnoViewModel alumnoViewModel;
    private TextView Carrera, txtMatricula ,txtNombre, txtCarrera;
    private TextInputEditText editTextCorreo, editTextCelular,editTextCalle, editTextColonia, editTextCP, editTextPoblacion, editTextLocalidad;
    private RequestQueue requestQueue;
    private ImageView imgUsuario;
    String fotografia, matricula, ApellidoPaterno, ApellidoMaterno, Nombre, nombreCarrera, correo, celular, direccion, colonias, CP, poblacion, localidad;
    private String ActualFotografia;

    private static final String PREFS_NAME = "MyPrefsFile";

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_perfil, container, false);

        //inicarlizar la cola de solicitudes volley
        requestQueue = Volley.newRequestQueue(requireContext());

        imgUsuario = rootView.findViewById(R.id.imgUsuario);
        txtMatricula = rootView.findViewById(R.id.txtMatricula);
        txtNombre = rootView.findViewById(R.id.txtNombre);
        txtCarrera = rootView.findViewById(R.id.txtCarrera);
        editTextCorreo = rootView.findViewById(R.id.editTextCorreo);
        editTextCelular = rootView.findViewById(R.id.editTextCelular);
        editTextCalle = rootView.findViewById(R.id.editTextCalle);
        editTextColonia = rootView.findViewById(R.id.editTextColonia);
        editTextCP = rootView.findViewById(R.id.editTextCP);
        editTextPoblacion = rootView.findViewById(R.id.editTextPoblacion);
        editTextLocalidad = rootView.findViewById(R.id.editTextLocalidad);

        // Obtener las preferencias compartidas
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);




        //Cargar los datos guardados en SharedPreferences
        cargarDatosPerfilSharedPreferences(sharedPreferences);

        //Obtener la refencia del ViewModel
        alumnoViewModel = new ViewModelProvider(requireActivity()).get(AlumnoViewModel.class);

        //ibservar lso cambios en la LiveData de nombre de carrera
        alumnoViewModel.getNombreCarrera().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String newNombreCarrera) {
                if (newNombreCarrera != null){
                    txtCarrera.setText(newNombreCarrera);
                    guardarNombreCarreraSharedPreferences(newNombreCarrera);
                }
            }
        });

        //Observa los cambios en la LiveData
        alumnoViewModel.getDatosAlumnoJSON().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String datosAlumnoJSON) {
                if (datosAlumnoJSON != null){
                    Log.d("JSON PERFIL_FRAGMENT", "DATOS: " + datosAlumnoJSON);

                    try{
                        JSONObject jsonObject = new JSONObject(datosAlumnoJSON);

                        //Obtener los valores del JSON
                        matricula = jsonObject.getString("matricula");
                        consultarDatosActuales(matricula);

                    }catch (JSONException e){
                        e.printStackTrace();
                        Log.d("JSON ERROR DATOS PERFIL", "ERROR al parsear el JSON " + e.getMessage() );
                        Toast.makeText(getActivity(), "Error al obtener los datos. Vuelva más tarde", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        PerfilBottomSheet perfilBottomSheet = new PerfilBottomSheet(requireContext());

        Button btnEditar = rootView.findViewById(R.id.btnEditar);
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //BottomSheetDialog perfilBottomSheet = new BottomSheetDialog(requireContext());
                performHapticFeedBack(v);
             
                perfilBottomSheet.show(matricula, correo, celular, direccion, colonias, CP, poblacion, localidad);

            }
        });

        Button btnCerrarSesion = rootView.findViewById(R.id.btnCerrarSesion);
        btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    performHapticFeedBack(v);
                    lougout();
                    clearCacheDatos();
                    Toast.makeText(requireContext(), "Sesión Cerrada", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LogoutListener){
            logoutListener = (LogoutListener) context;
        }else {
            throw new RuntimeException(context.toString() + "must implement LogoutListener");
        }

        // Inicializar el Vibrator
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
    }

    public interface LogoutListener{
        void onLogout();
    }

    private void cargarDatosPerfilSharedPreferences(SharedPreferences sharedPreferences) {
        // Obtener los datos guardados en SharedPreferences
        matricula = sharedPreferences.getString("matricula", "");
        Nombre = sharedPreferences.getString("Nombre", "");
        ApellidoPaterno = sharedPreferences.getString("ApellidoPaterno", "");
        ApellidoMaterno = sharedPreferences.getString("ApellidoMaterno", "");
        nombreCarrera = sharedPreferences.getString("nombreCarrera", "");

        correo = sharedPreferences.getString("correo", "");
        celular = sharedPreferences.getString("celular", "");
        colonias = sharedPreferences.getString("colonias", "");
        direccion = sharedPreferences.getString("direccion", "");
        CP = sharedPreferences.getString("CP", "");
        poblacion = sharedPreferences.getString("poblacion", "");
        localidad = sharedPreferences.getString("localidad", "");

        // Actualizar la interfaz de usuario con los nuevos datos
        txtMatricula.setText(matricula);
        txtNombre.setText(Nombre + " " + ApellidoPaterno + " " + ApellidoMaterno);
        txtCarrera.setText(nombreCarrera);
        editTextCorreo.setText(correo);
        editTextCelular.setText(celular);
        editTextCalle.setText(direccion);
        editTextColonia.setText(colonias);
        editTextCP.setText(CP);
        editTextPoblacion.setText(poblacion);
        editTextLocalidad.setText(localidad);

    }


    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    //Metodo para consultar datos actuales del alumno
    private void consultarDatosActuales(final String matricula){
        if (!isNetworkAvailable()) {
            Toast.makeText(getActivity(), "No hay conexión a Internet. Revisa tu conexión", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "https://connectmzt.com/app/indexDatosAlumno.php";

        JSONObject jsonBody = new JSONObject();
        try{
            jsonBody.put("matricula", matricula);
        }catch (JSONException e){
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("PERFIL-RESPONSE-JSON", response.toString());
                        try {
                            if (response.getBoolean("success")) {

                                JSONObject alumnoJSON = response.getJSONObject("0");

                                String Actualmatricula = alumnoJSON.getString("matricula");
                                String ApellidoPaterno = alumnoJSON.getString("ApellidoPaterno");
                                String ApellidoMaterno = alumnoJSON.getString("ApellidoMaterno");
                                String Nombre = alumnoJSON.getString("Nombre");
                                ActualFotografia = alumnoJSON.getString("fotografia");

                                String correo = alumnoJSON.getString("correo");
                                String celular = alumnoJSON.getString("celular");

                                String direccion = alumnoJSON.getString("direccion");
                                String colonias = alumnoJSON.getString("colonias");
                                String CP = alumnoJSON.getString("CP");
                                String poblacion = alumnoJSON.getString("poblacion");
                                String localidad = alumnoJSON.getString("localidad");

                                Log.d("PERFIL-NEW-RESPONSE-JOSN", Nombre);

                                Log.d("PERFIL-FRAGMENT", "NOMBRE fotografia" + ActualFotografia);

                                //Poner imagen del usuario con Glide
                               if(ActualFotografia != null && !ActualFotografia.isEmpty()){
                                   String URL_IMG = "https://connectmzt.com/app/views/imgAlumnos/" + ActualFotografia;
                                   Log.d("GLIDE", "URL DE LA IMAGEN: " + URL_IMG );

                                   Glide.with(PerfilFragment.this)
                                           .load(URL_IMG)
                                           .circleCrop()
                                           .placeholder(R.drawable.cargando)
                                           .error(R.drawable.imgerror)
                                           .into(imgUsuario);
                               }else {
                                   Log.d("GLIDE","NO SE ENCONTRÓ LA IMAGEN DEL ALUMNO");
                                   imgUsuario.setImageResource(R.drawable.imgerror);
                               }



                                guardarDatosPerfilSharedPreferences(correo, celular, direccion, colonias, CP, poblacion, localidad, Actualmatricula, ApellidoPaterno, ApellidoMaterno, Nombre);


                            } else {

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "Error al procesar la respuesta" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error de red.", Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(request);

    }

    //Metodo para cerrar la sesion del fragmento
    private void lougout(){
        if (logoutListener != null){
            logoutListener.onLogout();
        }
    }

}