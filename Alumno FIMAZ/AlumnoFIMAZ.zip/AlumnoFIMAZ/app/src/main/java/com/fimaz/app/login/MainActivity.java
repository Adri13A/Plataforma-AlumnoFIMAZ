package com.fimaz.app.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.SharedPreferences;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.fimaz.app.R;
import com.fimaz.app.fragments.InicioFragment;
import com.fimaz.app.fragments.PerfilFragment;
import com.fimaz.app.menu.InicioActivity;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity implements PerfilFragment.LogoutListener {

    private RequestQueue requestQueue;
    private Button btnLogin;
    public static final String PREFS_NAME = "MyPrefsFile";
    public static final String SESSION_KEY = "session";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Verificar si la sesion esta iniciada
        if(isSessionActive()){
            //si la sesion esta, activa redirigir al usuario a la pantalla de inicio
            goToInicioActivity();
        }

        ImageView logo_login = findViewById(R.id.logo_login);
        ImageView imageBackground = findViewById(R.id.imageBackground);

        int temaActual = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;

        //Se establece la imagen correspondiente segun el modo del tema
        switch (temaActual){
            case Configuration.UI_MODE_NIGHT_YES:
                logo_login.setImageResource(R.drawable.logofimazlight);
                break;
            case Configuration.UI_MODE_NIGHT_NO:
            case Configuration.UI_MODE_NIGHT_UNDEFINED:
            default:
                logo_login.setImageResource(R.drawable.logofimaz);
                break;
        }

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES){
            imageBackground.setImageResource(R.drawable.splash_dark);
        }else {
            imageBackground.setImageResource(R.drawable.splash_light);
        }

        //inicarlizar la cola de solicitudes volley
        requestQueue = Volley.newRequestQueue(this);

        //Boton inicar sesion manda a la pantalla de inicio
        btnLogin = findViewById(R.id.btnLogin);

        TextInputEditText matriculaEditText = findViewById(R.id.matriculaTIL);
        matriculaEditText.setFilters(new InputFilter[]{new InputFilterMatricula()});

        //Agregar el TextWacher
        matriculaEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().contains("-") && s.toString().length() == 8){
                    s.insert(7, "-");
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String matricula = ((EditText) findViewById(R.id.matriculaTIL)).getText().toString();
                String nip = ((EditText) findViewById(R.id.nipTIL)).getText().toString();

                btnLogin.setEnabled(false);
                //Vibrar utilizando HapticFeedBackConstats si esta disponible
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);

                // También puedes usar Vibrator para dispositivos más antiguos
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator != null){
                        VibrationEffect effect = VibrationEffect.createOneShot(1, VibrationEffect.DEFAULT_AMPLITUDE);
                        vibrator.vibrate(effect);
                    }
                }else{
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator != null) {
                        vibrator.vibrate(1);
                    }
                }

                login(matricula, nip);
            }
        });

    }

    private boolean isSessionActive(){
        //obtener el sharedPreferenes
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        //Verificar si la sesion está actica
        return preferences.getBoolean(SESSION_KEY, false);
    }

    //Metodo para redigir al usuario a la pantalla de inicio
    private void goToInicioActivity(){
        //Si la sesion esta activa, dirigir al usuario directamente a al pantalla de inicio
        Intent intent = new Intent(MainActivity.this, InicioActivity.class);
        startActivity(intent);
        finish();//Para que el usuario no pueda volver atras presionandoe el boton de "atras"
    }


    private void setSessionActive(boolean isActive){
        //obtener el sharedPreferences
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();

        //Establercer el estado de la sesion
        editor.putBoolean(SESSION_KEY, isActive);
        editor.apply();
    }
    private void login(String matricula, String nip){

        String url = "https://connectmzt.com/app/";

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("matricula", matricula);
            jsonBody.put("nip", nip);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.d("RESPONSE_JSON", response.toString());

                        btnLogin.setEnabled(true);
                        // Manejar la respuesta exitosa
                        try {
                            // Si la respuesta contiene un campo llamado "success" con valor true
                            if (response.getBoolean("success")) {
                                //Obtener los datos del alumnoo del JSON
                                JSONObject alumnoJson = response.getJSONObject("0");

                                String jsonResponse = alumnoJson.toString();

                                //int idCarrera = alumnoJson.getInt("Carrera");

                                //Mostrar el IDd de la carrera en el log
                                //Log.d("ID_Carrera", "ID de la carrera " + idCarrera);
                                //String jsonResponse = alumnoJson.toString();

                                //Crear un Bundle para pasar los dattos del alumno al fragmento InicioFragment
                                //Bundle bundle = new Bundle();
                                //bundle.putString("datos_alumno_json", jsonResponse);

                                // Crear una instancia del fragmento InicioFragment y pasarle el Bundle
                                //InicioFragment inicioFragment = new InicioFragment();
                                //inicioFragment.setArguments(bundle);

                                // Si el inicio de sesión es exitoso, redirigir a la pantalla de inicio
                                Intent intent = new Intent(MainActivity.this, InicioActivity.class);
                                intent.putExtra("datos_alumno_json", jsonResponse);
                                startActivity(intent);
                                Toast.makeText(MainActivity.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                                setSessionActive(true);
                                finish();
                            } else {
                                // Si el inicio de sesión falla, mostrar un mensaje de error
                               // Toast.makeText(MainActivity.this, "Matrícula o NIP incorrectos", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            btnLogin.setEnabled(true);

                            Toast.makeText(MainActivity.this, "Matrícula o NIP incorrectos", Toast.LENGTH_SHORT).show();
                        }
                    }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Manejar el error de la solicitud
                        Toast.makeText(MainActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();

                        //Habilirar el boton de login despues 5 segundos
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                btnLogin.setEnabled(true);
                            }
                        }, 5000);
                    }
                });

        // Agregar la solicitud a la cola de solicitudes
        requestQueue.add(request);
    }


    // Método para cerrar sesión (llámalo cuando el usuario quiera cerrar sesión)
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    @Override
    public void onLogout() {
        //super.onDestroy();
        setSessionActive(false);
    }

}