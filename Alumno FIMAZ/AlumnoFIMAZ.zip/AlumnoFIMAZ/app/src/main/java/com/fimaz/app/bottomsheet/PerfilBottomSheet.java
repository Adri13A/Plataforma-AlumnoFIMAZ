package com.fimaz.app.bottomsheet;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fimaz.app.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class PerfilBottomSheet {
    private Context context;
    private Vibrator vibrator;
    private String matricula, correo, celular, direccion, colonias, CP, poblacion, localidad;
    private RequestQueue requestQueue;

    public PerfilBottomSheet(Context context) {
        this.context = context;
        requestQueue = Volley.newRequestQueue(context);
    }

    public void show(String matricula, String correo, String celular, String direccion, String colonias, String CP, String poblacion, String localidad) {
        this.matricula = matricula;
        this.correo = correo;
        this.celular = celular;
        this.direccion = direccion;
        this.colonias = colonias;
        this.CP = CP;
        this.poblacion = poblacion;
        this.localidad = localidad;

        Log.d("PERFIL BOTTOM SHEET", "MATRICULA " + matricula);

        final BottomSheetDialog dialog = new BottomSheetDialog(context);
        dialog.setContentView(R.layout.bottom_sheet_layout_perfil);

        TextInputEditText etBCorreo = dialog.findViewById(R.id.editTextCorreo);
        TextInputEditText etBCelular = dialog.findViewById(R.id.editTextCelular);
        TextInputEditText etBdireccion = dialog.findViewById(R.id.editTextCalle);
        TextInputEditText etBColonia = dialog.findViewById(R.id.editTextColonia);
        TextInputEditText etBCP = dialog.findViewById(R.id.editTextCP);
        TextInputEditText etBPoblacion = dialog.findViewById(R.id.editTextPoblacion);
        TextInputEditText etBLocalidad = dialog.findViewById(R.id.editTextLocalidad);

        etBCorreo.setText(correo);
        etBCelular.setText(celular);
        etBdireccion.setText(direccion);
        etBColonia.setText(colonias);
        etBCP.setText(CP);
        etBPoblacion.setText(poblacion);
        etBLocalidad.setText(localidad);

        Button btnGuardar = dialog.findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performHapticFeedBack(v);
                // Obtener los datos actualizados
                String updatedCorreo = etBCorreo.getText().toString().trim();
                String updatedCelular = etBCelular.getText().toString().trim();
                String updatedDireccion = etBdireccion.getText().toString().trim();
                String updatedColonias = etBColonia.getText().toString().trim();
                String updatedCP = etBCP.getText().toString().trim();
                String updatedPoblacion = etBPoblacion.getText().toString().trim();
                String updatedLocalidad = etBLocalidad.getText().toString().trim();

                // Crear un objeto JSON con los datos actualizados
                JSONObject nuevosDatos = new JSONObject();
                try {
                    nuevosDatos.put("matricula", matricula);
                    nuevosDatos.put("direccion", updatedDireccion);
                    nuevosDatos.put("colonias", updatedColonias);
                    nuevosDatos.put("CP", updatedCP);
                    nuevosDatos.put("poblacion", updatedPoblacion);
                    nuevosDatos.put("localidad", updatedLocalidad);
                    nuevosDatos.put("celular", updatedCelular);
                    nuevosDatos.put("correo", updatedCorreo);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                Log.d("PerfilBottomSheet", "Datos a enviar: " + nuevosDatos.toString());

                // Construir la solicitud HTTP
                String url = "https://connectmzt.com/app/indexActualizarDatos.php";
                JsonObjectRequest  request = new JsonObjectRequest(Request.Method.POST, url, nuevosDatos,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                Log.d("RESPONSE_JSON", response.toString());
                            
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // Manejar el error de la solicitud HTTP
                                Toast.makeText(context, "Error al actualizar los datos. Por favor, inténtalo de nuevo más tarde.", Toast.LENGTH_SHORT).show();
                                Log.e("PerfilBottomSheet", "Error en la solicitud HTTP: " + error.toString());
                            }
                        }) {
                };

                // Agregar la solicitud a la cola de solicitudes
                requestQueue.add(request);
            }
        });

        dialog.show();

        int maxHeight = context.getResources().getDisplayMetrics().heightPixels;
        dialog.getBehavior().setPeekHeight(maxHeight);
    }

    private void performHapticFeedBack(View v){
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);

        // También puedes usar Vibrator para dispositivos más antiguos
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator != null) {
            // Ajusta los parámetros de la vibración según tu preferencia
            VibrationEffect effect = VibrationEffect.createOneShot(1, VibrationEffect.DEFAULT_AMPLITUDE);
            vibrator.vibrate(effect);
        } else {
            // Para versiones anteriores a Oreo
            if (vibrator != null) {
                vibrator.vibrate(2);
            }
        }
    }
}

