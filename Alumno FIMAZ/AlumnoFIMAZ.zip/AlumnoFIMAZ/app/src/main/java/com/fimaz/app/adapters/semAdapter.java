package com.fimaz.app.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.fimaz.app.fragments.PeriodoFragment;
import com.fimaz.app.periodos.periodo1;
import com.fimaz.app.periodos.periodo2;
import com.fimaz.app.periodos.periodo3;
import com.fimaz.app.periodos.periodo4;
import com.fimaz.app.periodos.periodo5;
import com.fimaz.app.periodos.periodo6;
import com.fimaz.app.periodos.periodo7;
import com.fimaz.app.periodos.periodo8;

public class semAdapter extends FragmentStateAdapter {

    public semAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        //Cada posicion correspondee a un periodo (posicion + 1)
        return PeriodoFragment.newInstance(position + 1);
    }

    @Override
    public int getItemCount() {
        return 8;
    }
}
