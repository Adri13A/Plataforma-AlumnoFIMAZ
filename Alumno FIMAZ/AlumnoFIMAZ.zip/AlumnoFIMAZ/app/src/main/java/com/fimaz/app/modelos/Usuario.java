package com.fimaz.app.modelos;

public class Usuario {

    private int idUsuario; // Ejemplo de ID de usuario
    private String nombre;
    private String apellido;
    private String matricula;
    private String nip;
    private String correoElectronico;
    private String telefono;
    private String tipoUsuario; // Ejemplo de tipo de usuario (alumno, profesor, etc.)
    private String estado; // Ejemplo de estado de la cuenta (activo, inactivo)
    private String fechaCreacion;

    public String getMatricula() {
        return matricula;
    }

    public String getNip() {
        return nip;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }
}

