package com.fimaz.app.bottomSheetsLayouts;

import com.fimaz.app.fragments.PerfilFragment;

public class EditarPerfilBottomSheet extends PerfilFragment {
}
