package com.fimaz.app.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.fimaz.app.AlumnoViewModel;
import com.fimaz.app.adapters.InicioAdapter;
import com.fimaz.app.modelos.InicioItem;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class InicioFragment extends Fragment {

    private RecyclerView mrecyclerView;
    private InicioAdapter mAdapter;
    private RecyclerView.LayoutManager mlayoutManager;
    private TextView txtAlumnoCarrera;
    private RequestQueue requestQueue;
    private String datosAlumnoJSON, matricula, matriculaGuardada;
    private int idCarrera, periodo, periodoGuardado;
    private AlumnoViewModel alumnoViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflar el layout del fragmento
        View rootView = inflater.inflate(R.layout.fragment_inicio, container, false);

        requestQueue = Volley.newRequestQueue(requireContext());
        //Nombre de la carra se obtendra por el ID
        txtAlumnoCarrera = rootView.findViewById(R.id.txtAlumnoCarrera);

        alumnoViewModel = new ViewModelProvider(requireActivity()).get(AlumnoViewModel.class);
        datosAlumnoJSON = getActivity().getIntent().getStringExtra("datos_alumno_json");

        

        alumnoViewModel.setDatosAlumnoJSON(datosAlumnoJSON);

        // Verificar si ya hay un nombre de carrera guardado en SharedPreferences
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MyPrefsFile", Context.MODE_PRIVATE);
        String nombreCarreraGuardado = sharedPreferences.getString("nombre_carrera", null);
        if (nombreCarreraGuardado != null) {
            // Si hay un nombre guardado, establecerlo en txtAlumnoCarrera
            txtAlumnoCarrera.setText(nombreCarreraGuardado);
        } else {
            // Si no hay un nombre guardado, obtener el ID de la carrera y buscar el nombre
            idCarrera = getActivity().getIntent().getIntExtra("Carrera", -1);
            if (idCarrera != -1) {
                buscarNombreCarrera(idCarrera);
            }
        }
        matriculaGuardada = sharedPreferences.getString("matricula", "");
        periodoGuardado = sharedPreferences.getInt("periodo", -1);

        Log.d("INICIO-FRAG JSON-MAATRICULA", "VALOR GUARDADO MATRICULA: " + matriculaGuardada);
        Log.d("INICIO-FRAG JSON-PERIODO", "VALOR GUARDADO PERIODO: " + periodoGuardado);

        // Obtener el horario de la API y guardar en SharedPreferences
        obtenerHorario(matriculaGuardada, periodoGuardado, sharedPreferences);

        // Cargar el horario desde SharedPreferences
        List<InicioItem> horarioList = cargarHorarioDesdeSharedPreferences(sharedPreferences);

        // Configurar el RecyclerView
        mrecyclerView = rootView.findViewById(R.id.recyclerView);

        mrecyclerView.setHasFixedSize(true);
        mlayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new InicioAdapter(horarioList, getContext());



        mrecyclerView.setLayoutManager(mlayoutManager);
        mrecyclerView.setAdapter(mAdapter);

        return rootView;
    }

    private void buscarNombreCarrera(int idCarrera) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MyPrefsFile", Context.MODE_PRIVATE);

        String url = "https://connectmzt.com/app/indexCarrera.php";

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("id_Carrera", idCarrera);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            final String nombreCarrera = response.getString("NombreCarrera");

                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("nombre_carrera", nombreCarrera);
                            editor.apply();

                            Log.d("Carrera", "Nombre de la carrera: " + nombreCarrera);

                            alumnoViewModel.setNombreCarrera(nombreCarrera);

                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    txtAlumnoCarrera.setText(nombreCarrera);
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("Carrera", "Error al obtener el nombre de la carrera: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error al obtener el nombre de la carrera", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);
    }

    private void obtenerHorario(String matricula, int periodo, SharedPreferences sharedPreferences) {
        String URL_API = "https://connectmzt.com/app/indexHorario.php";

        JSONObject postData = new JSONObject();
        try {
            postData.put("matricula", matricula);
            postData.put("periodo", periodo);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        CustomJsonArrayRequest request = new CustomJsonArrayRequest(Request.Method.POST, URL_API, postData,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        if (!isAdded()) {
                            return;
                        }

                        requireActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                List<InicioItem> horarioList = new ArrayList<>();
                                SharedPreferences.Editor editor = sharedPreferences.edit();

                                try {
                                    for (int i = 0; i < response.length(); i++) {
                                        JSONObject horario = response.getJSONObject(i);

                                        Log.d("INICIO-FRAG", "DATOS-HORARIO: " + horario);

                                        String nombreMateria = horario.getString("nombre_materia");
                                        String claseHorario = horario.getString("horario");
                                        String aula = horario.getString("aula");
                                        String nombreMaestro = horario.getString("nombre_maestro");
                                        String imagenUrl = "https://connectmzt.com/app/views/imgMaterias/" + horario.getString("imagen");
                                        String color = horario.getString("color");

                                        InicioItem item = new InicioItem(imagenUrl, nombreMateria, claseHorario, aula, nombreMaestro, color);
                                        horarioList.add(item);
                                    }

                                    mAdapter.setHorarioList(horarioList);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                String horarioListJson = convertirListaAHorarioJson(horarioList);
                                editor.putString("horario_list", horarioListJson);
                                editor.apply();
                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(getActivity(), "Error al obtener el horario", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);
    }


}
