package com.fimaz.app.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InsertGesture;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fimaz.app.AlumnoViewModel;
import com.fimaz.app.R;
import com.fimaz.app.adapters.semAdapter;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KardexFragment extends Fragment {

    private TextView semestreTextView, promGenNumTextView, promSemNumTextView;
    private TabLayout tabLayout;
    private ViewPager2 viewPager2;
    private RequestQueue requestQueue;
    private AlumnoViewModel alumnoViewModel;
    private String matricula;
    private static final String PREFS_NAME = "MyPrefsFile";
    private Map<Integer, List<Integer>> calificacionesPorPeriodo = new HashMap<>();
    private List<Integer> calificacionesGenerales = new ArrayList<>();
    private int maxPeriodo = 0;
    com.fimaz.app.adapters.semAdapter semAdapter;


    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceeState){
        super.onViewCreated(view, savedInstanceeState);

        //Obtener el view model
        alumnoViewModel = new ViewModelProvider(requireActivity()).get(AlumnoViewModel.class);

        //Observar los datos del alumno
        alumnoViewModel.getDatosAlumnoJSON().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String datosAlumnoJSON) {

                if(datosAlumnoJSON != null && !datosAlumnoJSON.isEmpty()){
                    Log.d("JSON-KARDE-FRAG", "Datos alumno: " + datosAlumnoJSON);

                    try{
                        JSONObject jsonObject = new JSONObject(datosAlumnoJSON);

                        matricula = jsonObject.getString("matricula");
                        Log.d("JSON MATRICULA", "Matricula: " + matricula);

                        //Guardar la matricula en SharedPreferences
                        saveMatriculaToSharedPreferences(matricula);

                        // Llamar a consultarAllCalificaciones después de obtener la matricula
                        consultaAllCalificaciones(matricula);

                    }catch (JSONException ex){
                        ex.printStackTrace();
                        Log.d("ERROR-KARDEX-FRAG", "Error al parsear el JSON: " + ex.getMessage());
                    }
                }else{
                    Log.d("ERROR-KARDEX", "No se recibieron los datos");

                    String savedMatriculaKardex = getMatriculaFromSharesPreferences();
                    if (savedMatriculaKardex != null){
                        matricula = savedMatriculaKardex;
                        consultaAllCalificaciones(matricula);
                    } else {
                        Log.d("ERROR-KARDEX", "No se encontró la matrícula en SharedPreferences");
                    }
                }
            }
        });

    }

    private  String getMatriculaFromSharesPreferences(){
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        //Si no encuentra la matricula, devuelve null
        return sharedPreferences.getString("matricula", null);
    }

    private void saveMatriculaToSharedPreferences(String matricula){
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("matricula", matricula);
        editor.apply();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_kardex, container, false);

        promGenNumTextView = rootView.findViewById(R.id.promGenNumTextView);
        promSemNumTextView = rootView.findViewById(R.id.promSemNumTextView);
        semestreTextView = (TextView) rootView.findViewById(R.id.semestreTextView);
        tabLayout = rootView.findViewById(R.id.tabLayaout);
        viewPager2 = rootView.findViewById(R.id.viewPager);

        FragmentManager fragmentManager = getChildFragmentManager();
        Lifecycle lifecycle = getLifecycle();
        semAdapter = new semAdapter(fragmentManager, lifecycle);
        requestQueue = Volley.newRequestQueue(requireContext());

        viewPager2.setAdapter(semAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();  // Obtener el número de periodo
                viewPager2.setCurrentItem(position);
                semestreTextView.setText("Periodo " + tab.getText());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.getTabAt(position).select();
            }
        });

        if (matricula != null){
            if (getArguments() != null){
                consultaAllCalificaciones(matricula);
            }
        }

        return rootView;
    }

    private void consultaAllCalificaciones(String matricula) {
        String URL = "https://connectmzt.com/app/indexAllCalificaciones.php";

        JSONObject postData = new JSONObject();
        try {
            postData.put("matricula", matricula);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        CustomJsonArrayRequest request = new CustomJsonArrayRequest(Request.Method.POST, URL, postData,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("KARDEX-RESPONSE-JSON", response.toString()); // Verificar la respuesta en los registros

                        try {
                            calificacionesPorPeriodo.clear();
                            calificacionesGenerales.clear();
                            maxPeriodo = 0;

                            //Iterar sobre el JSONArray agregar las filas a la tabla
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject calificacion = response.getJSONObject(i);

                                //Extraer y manejar los datos de la calificaciones
                                int periodo = calificacion.getInt("periodo");
                                String calificacionAlumnoStr = calificacion.getString("CalificacionAlumno");

                                //Convertir de string a integer
                                int calificacionesGeneralesAlumno;
                                try{
                                    calificacionesGeneralesAlumno = Integer.parseInt(calificacionAlumnoStr);
                                }catch (NumberFormatException e){
                                    Log.d("KARDEX-JSON", "Error la calificacion a int: " + calificacionAlumnoStr);
                                    continue; //Saltar esta calificacion si hay un error
                                }

                                //Agregar la calificacion al promedio general
                                calificacionesGenerales.add(calificacionesGeneralesAlumno);


                                ////Agregar la calificacion al mapa calificaciones por periodo
                                if(!calificacionesPorPeriodo.containsKey(periodo)){
                                    calificacionesPorPeriodo.put(periodo, new ArrayList<>());
                                }

                                calificacionesPorPeriodo.get(periodo).add(calificacionesGeneralesAlumno);

                                //Actualizar el periodo mas alto
                                if(periodo > maxPeriodo){
                                    maxPeriodo = periodo;
                                }

                                Log.d("KARDEX-JSON", "DATA: " + calificacionAlumnoStr + ", " + periodo);

                                // ... (Resto de tu código para manejar cada calificación)
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(requireContext(), "Error al analizar las calificaciones", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Manejar errores de la solicitud
                        error.printStackTrace();
                        Toast.makeText(requireContext(), "Error en la solicitud", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);
    }

    private TextView createTextView(String text){
        TextView textView = new TextView(requireContext());
        textView.setText(text);
        textView.setPadding(16,16,16,16);
        return textView;
    }
   
}