package com.fimaz.app.menu;

import static com.fimaz.app.login.MainActivity.PREFS_NAME;
import static com.fimaz.app.login.MainActivity.SESSION_KEY;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.fimaz.app.AlumnoViewModel;
import com.fimaz.app.login.MainActivity;
import com.fimaz.app.R;
import com.fimaz.app.fragments.KardexFragment;
import com.fimaz.app.fragments.InicioFragment;
import com.fimaz.app.fragments.PerfilFragment;
import com.fimaz.app.fragments.RecursosFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class InicioActivity extends AppCompatActivity implements PerfilFragment.LogoutListener {

    private BottomNavigationView bottomNavigationView;
    private FrameLayout frameLayout;
    private Vibrator vibrator;
    private AlumnoViewModel alumnoViewModel;
    private static final String KEY_SELECTED_FRAGMENT = "seleted_fragment";
    private int selectedFragmentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        //Inctanciar el ViewModel
        alumnoViewModel = new ViewModelProvider(this).get(AlumnoViewModel.class);

        //Obtener los datos del alumno desde el intent
        String datosAlumnoJSON = getIntent().getStringExtra("datos_alumno_json");
        if(datosAlumnoJSON != null){
            alumnoViewModel.setDatosAlumnoJSON(datosAlumnoJSON);
        }

        bottomNavigationView = findViewById(R.id.bottonNavigationView);
        frameLayout = findViewById(R.id.frameLayout);

        if (savedInstanceState != null){
            selectedFragmentId = savedInstanceState.getInt(KEY_SELECTED_FRAGMENT);
        }else {
            selectedFragmentId = R.id.navigation_home;
        }

        loadFragment(selectedFragmentId);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                loadFragment(itemId);
                performHapticFeedback();
                return true;
            }
        });


    }

    protected void onSaveInstanceState(@NonNull Bundle outState){
        super.onSaveInstanceState(outState);

        //Guardar el ID del fragmento seleccionado
        outState.putInt(KEY_SELECTED_FRAGMENT, selectedFragmentId);
    }
    private void loadFragment(int itemId){
        selectedFragmentId = itemId;

        Fragment fragment = null;

        if (itemId == R.id.navigation_home) {
            fragment = new InicioFragment();
        } else if (itemId == R.id.navigation_kardex) {
            fragment = new KardexFragment();
        } else if (itemId == R.id.navigation_recursos) {
            fragment = new RecursosFragment();
        } else if (itemId == R.id.navigation_perfil) {
            fragment = new PerfilFragment();
        }

        if (fragment != null){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frameLayout, fragment).addToBackStack(null);
            fragmentTransaction.commit();
        }
    }

    @Override
    public void onLogout() {
        // Llama al método setSessionActive con el valor false para cerrar la sesión
        setSessionActive(false);

        // Redirige al usuario de vuelta a la pantalla de inicio de sesión (MainActivity)
            Intent intent = new Intent(InicioActivity.this, MainActivity.class);
            startActivity(intent);
            finish();// Cierra la actividad actual para evitar que el usuario vuelva atrás con el botón de atrás
    }


    private void setSessionActive(boolean isActive){
        // Aquí implementa el código para establecer el estado de la sesión
        SharedPreferences.Editor editor=getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putBoolean(SESSION_KEY, isActive);
        editor.apply();
    }

    // Método para realizar la vibración háptica
    private void performHapticFeedback() {
        // Vibrar utilizando HapticFeedbackConstants si está disponible
        bottomNavigationView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);

        // También puedes usar Vibrator para dispositivos más antiguos
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator != null) {
            // Ajusta los parámetros de la vibración según tu preferencia
            VibrationEffect effect = VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE);
            vibrator.vibrate(effect);
        } else {
            // Para versiones anteriores a Oreo
            if (vibrator != null) {
                vibrator.vibrate(20);
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}