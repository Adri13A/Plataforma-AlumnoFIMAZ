package com.fimaz.app.moodle;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fimaz.app.R;

public class vistaFIMAZ extends Fragment {

    private WebView webViewMoodle;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_vista_f_i_m_a_z, container, false);
        webViewMoodle = rootView.findViewById(R.id.moodleWebView);
        setupWebView();
        loadMoodlePage();
        return rootView;
    }

    private void setupWebView() {
        WebSettings webSettingsMoodle = webViewMoodle.getSettings();
        webSettingsMoodle.setJavaScriptEnabled(true);
        webSettingsMoodle.setAllowContentAccess(true);
        webSettingsMoodle.setBuiltInZoomControls(true);
        webSettingsMoodle.setDisplayZoomControls(false);
        webSettingsMoodle.setLoadWithOverviewMode(true);
        webSettingsMoodle.setUseWideViewPort(true);

        webViewMoodle.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                Toast.makeText(getContext(), "Error al cargar la vista inmersiva del Moodle", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadMoodlePage() {
        webViewMoodle.loadUrl("https://moodle.fimaz.uas.edu.mx/");
    }
}
