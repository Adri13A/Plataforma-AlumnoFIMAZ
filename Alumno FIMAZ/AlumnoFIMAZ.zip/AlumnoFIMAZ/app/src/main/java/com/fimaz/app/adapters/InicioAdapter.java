package com.fimaz.app.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fimaz.app.modelos.InicioItem;
import com.fimaz.app.R;
import java.util.List;

public class InicioAdapter extends RecyclerView.Adapter<InicioAdapter.InicioViewHolder> {

    private boolean mostrarDetalles = false;
    private List<InicioItem> horarioList;
    private Context context;

    public static class InicioViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView materiaTextView, horaTextView, aulaTextView, profesorTextView;
        public CardView cardView;

        public InicioViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imagenItem);
            materiaTextView = itemView.findViewById(R.id.PromedioGenTextView);
            horaTextView = itemView.findViewById(R.id.HhoraItem);
            aulaTextView = itemView.findViewById(R.id.aulaItem);
            profesorTextView = itemView.findViewById(R.id.profesorItem);
            cardView = itemView.findViewById(R.id.card_view);
        }
    }

    public InicioAdapter() {
        // Constructor vacío necesario para la instanciación del sistema
    }

    public InicioAdapter(List<InicioItem> horarioList, Context context) {
        this.horarioList = horarioList;
        this.context = context;
    }

    @NonNull
    @Override
    public InicioAdapter.InicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inicio, parent, false);
        return new InicioViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull InicioAdapter.InicioViewHolder holder, int position) {
        InicioItem currentItem = horarioList.get(position);

        Glide.with(holder.itemView.getContext())
                .load(currentItem.getImagenUrl())
                .placeholder(R.drawable.cargando)
                .error(R.drawable.imgerror)
                .into(holder.imageView);

        holder.materiaTextView.setText(currentItem.getMateria());

        // Mostrar u ocultar detalles según el estado mostrarDetalle
        /*if (mostrarDetalles) {
            holder.aulaTextView.setVisibility(View.VISIBLE);
            holder.profesorTextView.setVisibility(View.VISIBLE);
            holder.horaTextView.setVisibility(View.VISIBLE);
            holder.aulaTextView.setText(currentItem.getAula());
            holder.profesorTextView.setText(currentItem.getProfesor());
            holder.horaTextView.setText(currentItem.getHorario());
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        } else {
            holder.aulaTextView.setVisibility(View.GONE);
            holder.profesorTextView.setVisibility(View.GONE);
            holder.horaTextView.setVisibility(View.GONE);
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        }
        if (mostrarDetalles) {
            animateViewVisibility(holder.aulaTextView, true);
            animateViewVisibility(holder.profesorTextView, true);
            animateViewVisibility(holder.horaTextView, true);
            holder.aulaTextView.setText(currentItem.getAula());
            holder.profesorTextView.setText(currentItem.getProfesor());
            holder.horaTextView.setText(currentItem.getHorario());
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        } else {
            animateViewVisibility(holder.aulaTextView, false);
            animateViewVisibility(holder.profesorTextView, false);
            animateViewVisibility(holder.horaTextView, false);
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        }
        */

        /*
        holder.materiaTextView.setText(currentItem.getMateria());
        holder.aulaTextView.setText(currentItem.getAula());
        holder.profesorTextView.setText(currentItem.getProfesor());
        holder.horaTextView.setText(currentItem.getHorario());
        */

        if (currentItem.isExpanded()) {
            holder.aulaTextView.setVisibility(View.VISIBLE);
            holder.profesorTextView.setVisibility(View.VISIBLE);
            holder.horaTextView.setVisibility(View.VISIBLE);
            holder.aulaTextView.setText(currentItem.getAula());
            holder.profesorTextView.setText(currentItem.getProfesor());
            holder.horaTextView.setText(currentItem.getHorario());
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        } else {
            holder.aulaTextView.setVisibility(View.GONE);
            holder.profesorTextView.setVisibility(View.GONE);
            holder.horaTextView.setVisibility(View.GONE);
            holder.cardView.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        }

        //Establer el color de fondo del CardView
        try{
            int color;
            String colorName = currentItem.getColor();
            Context context = holder.itemView.getContext();

            // Verificar si el color es un color hexadecimal
            if (colorName.startsWith("#")) {
                color = Color.parseColor(colorName);
            } else {
                // Obtener el recurso del color por nombre
                int colorResId = context.getResources().getIdentifier(colorName, "color", context.getPackageName());
                if (colorResId != 0) {
                    color = ContextCompat.getColor(context, colorResId);
                } else {
                    throw new IllegalArgumentException("Color no encontrado");
                }
            }
            holder.cardView.setCardBackgroundColor(color);
        }catch (IllegalArgumentException e){
            holder.cardView.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.blue_back));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean expanded = !currentItem.isExpanded();
                currentItem.setExpanded(expanded);
                notifyItemChanged(holder.getPosition());
            }
        });

        // Mostrar u ocultar detalles
        if (currentItem.isExpanded()) {
            holder.aulaTextView.setVisibility(View.VISIBLE);
            holder.profesorTextView.setVisibility(View.VISIBLE);
            holder.horaTextView.setVisibility(View.VISIBLE);

            holder.aulaTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in));
            holder.profesorTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in));
            holder.horaTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in));
        } else {
            holder.aulaTextView.setVisibility(View.GONE);
            holder.profesorTextView.setVisibility(View.GONE);
            holder.horaTextView.setVisibility(View.GONE);

            holder.aulaTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_out));
            holder.profesorTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_out));
            holder.horaTextView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_out));
        }

    }

    @Override
    public int getItemCount() {
        return horarioList.size();
    }
    /*
    private void animateViewVisibility(View view, boolean visible) {
        if (visible) {
            view.setVisibility(View.VISIBLE);
            Animation animation = AnimationUtils.loadAnimation(context, R.anim.slide_in);
            view.startAnimation(animation);
        } else {
            Animation animation = AnimationUtils.loadAnimation(context, R.anim.slide_out);
            animation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {}

                @Override
                public void onAnimationEnd(Animation animation) {
                    view.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {}
            });
            view.startAnimation(animation);
        }
    }
    */


    public void setHorarioList(List<InicioItem> horarioList) {
        this.horarioList = horarioList;
        notifyDataSetChanged();
    }
}
