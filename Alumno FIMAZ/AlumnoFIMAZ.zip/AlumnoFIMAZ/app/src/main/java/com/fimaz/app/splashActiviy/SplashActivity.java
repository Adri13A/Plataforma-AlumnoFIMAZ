package com.fimaz.app.splashActiviy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.fimaz.app.R;
import com.fimaz.app.login.MainActivity;
import com.fimaz.app.menu.InicioActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView welcomeText = findViewById(R.id.welcomeText);
        TextView welcomeText2 = findViewById(R.id.welcomeText2);
        ImageView imageSplash = findViewById(R.id.imageSplash);

        // Cargar y aplicar la animación
        //Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slide_out);
        welcomeText.setVisibility(View.VISIBLE);
        //welcomeText.startAnimation(slideIn);
        welcomeText2.setVisibility(View.VISIBLE);
        //welcomeText2.startAnimation(slideIn);

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES){
            imageSplash.setImageResource(R.drawable.splash_dark);
            welcomeText.setTextColor(getResources().getColor(R.color.white));
            welcomeText2.setTextColor(getResources().getColor(R.color.white));
        }else {
            imageSplash.setImageResource(R.drawable.splash_light);
            welcomeText.setTextColor(getResources().getColor(R.color.black));
            welcomeText2.setTextColor(getResources().getColor(R.color.black));

        }

        //Retrasar la transicion a MainActivity

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //Iniciar MainActivity
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        },1500);


    }
}