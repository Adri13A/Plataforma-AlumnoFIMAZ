package com.fimaz.app.modelos;

public class InicioItem {

    private String materia, hora, aula, profesor, imagenUrl, color;
    private boolean mostrarDetalle, expanded;


    public InicioItem(String imagenUrl, String materia, String hora, String aula, String profesor, String color){
        this.imagenUrl = imagenUrl;
        this.materia = materia;
        this.hora = hora;
        this.aula = aula;
        this.profesor = profesor;
        this.color = color;
        this.expanded = false;
    }


    public String getImagenUrl() {
        return imagenUrl;
    }

    public String getMateria() {
        return materia;
    }

    public String getHorario() {
        return hora;
    }

    public String getAula() {
        return aula;
    }

    public String getProfesor() {
        return profesor;
    }


    public String getColor() {
        return color;
    }

    public boolean isMostrarDetalle() {
        return mostrarDetalle;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMostrarDetalle(boolean mostrarDetalle) {
        this.mostrarDetalle = mostrarDetalle;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }
}
