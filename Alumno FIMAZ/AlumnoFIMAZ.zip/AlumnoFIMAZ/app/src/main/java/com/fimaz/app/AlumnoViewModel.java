package com.fimaz.app;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AlumnoViewModel extends ViewModel {
    private MutableLiveData<String> datosAlumnoJSON = new MutableLiveData<>();

    private MutableLiveData<String> nombreCarrera = new MutableLiveData<>();

    public void setDatosAlumnoJSON(String datosAlumnoJSON){
        this.datosAlumnoJSON.setValue(datosAlumnoJSON);
    }

    public LiveData<String> getDatosAlumnoJSON(){
        return datosAlumnoJSON;
    }

    public void setNombreCarrera(String nombreCarrera){
        this.nombreCarrera.setValue(nombreCarrera);
    }
    public LiveData<String> getNombreCarrera(){
        return nombreCarrera;
    }


}
